declare module "@splinetool/react-spline/next" {
  const Spline: any;
  export default Spline;
}
