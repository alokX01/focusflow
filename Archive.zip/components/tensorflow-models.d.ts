declare module "@tensorflow-models/face-landmarks-detection";
